import json
import requests

def lambda_handler(event, context):
    url = "http://api.assignment.com"
    
    try:
        response = requests.get(url)
        response_data = {
            "statusCode": response.status_code,
            "headers": dict(response.headers),
            "body": response.text
        }
        
        print("Response:", json.dumps(response_data, indent=4))
        return response_data
        
    except Exception as e:
        error_message = f"Error: {str(e)}"
        print(error_message)
        return {
            "statusCode": 500,
            "body": json.dumps({"error": error_message})
        }